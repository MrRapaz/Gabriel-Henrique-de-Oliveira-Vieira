# Calcular a quantidade de litros de combustivel gastos em uma viagem. para
# obter o cálculo, o usuário deverá fornecer o tempo gasto, quantos km/l o
# carro faz e a velocidade média durante a viagem. O programa deverá
# apresentar os valores da velocidade média, tempo gasto na viagem, a distância percorrida e a quantidade de litros utilizados na viagem.

# tempo: tempo gasto
# kml: km por litro 
# velm: velocidade media
# dist: distancia percorrida
# litros: litros gasto na viagem

tempo = 0.0
kml = 0.0
velm = 0.0
dist = 0
litros = 0


tempo = float(input("Informe o tempo gasto na viagem: "))
kml = float(input("Informe quantos km por litro o carro faz:"))
velm = float(input("Informe a velocidade média:"))

dist = tempo * velm
litros = dist / kml

print(f"A valocidade media é de: {velm}")
print(f"O tempo gasto foi de: {tempo}")
print(f"A distancia percorrida foi: {dist}")
print(f"A quantidade de litros gasto foi de: {litros}")