#variavel
numero = 0

#algoritmo
while numero <= 10:
    print(f"O valor da variavel numero é: {numero}")
    numero +=1