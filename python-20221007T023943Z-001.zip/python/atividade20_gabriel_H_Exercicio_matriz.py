'''mostrar a diagonal principal de uma matriz 5x5'''

matriz = [[0.0]*5, [0.0]*5, [0.0]*5, [0.0]*5, [0.0]*5]
for cont1 in range (0,5,1):
    for cont2 in range (0,5,1):
         matriz [cont1][cont2]= int(input(f"Digite um valor para {cont1 + 1} , {cont2 + 1}: "))

for cont1 in range (0,5,1):
    for cont2 in range (0,5,1):
            print(f"{matriz[cont1][cont2]:^5}  ",end=" ")
    print()
print()
for cont1 in range (0,5,1):
    for cont2 in range (0,5,1):
        if cont1 == cont2 :
            print(f"{matriz[cont1][cont2]:^5}  ",end=" ")
        else:
            print("   ",end=" ")
    print()