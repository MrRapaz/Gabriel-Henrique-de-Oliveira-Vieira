""" Desenvolver um algoritmo que solicite o nome e a idade de um nadador e imprima na tela o
seu nome, a sua idade em qual categoria ele está.
      idade                      categoria
      5 a 7                      infantil A
      8 a 11                     infantil B
      12 a 13                    juvenil A
      14 a 17                    juvenil B
      18 a >                     adulto
 Caso seja digitado uma idade fora das classe acima, informar que o nadador não possui uma categoria válida.
 """
idade = 0
nome = ""
text = ""


nome = input("Informe seu nome: ")
idade = int(input("Informe sua idade: "))

if(idade < 5 and idade > 130):
    text = "valida"
else:
    if(idade >= 5 and idade <= 7):
        text = "infantil A"
    else:
        if(idade >=8 and idade <= 11 ):
            text = "infantil B"
        else:
            if(idade >=12 and idade <=13):
                text = "juvenil A"
            else:
                if(idade >= 14 and idade <=17):
                    text ="juvenil B"
                else:
                    text ="adulto"


print(f"{nome} você pertence a categoria {text}")