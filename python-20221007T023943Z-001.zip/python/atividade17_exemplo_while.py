#variavel

letra = "sim"

#algoritmo
while letra == "sim":
    print(f"Rodando o comando while em Python")
    letra = input("Deseja continuar: sim ou não: ")