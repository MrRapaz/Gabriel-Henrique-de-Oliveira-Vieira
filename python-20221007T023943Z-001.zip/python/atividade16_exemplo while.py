#variavel
numero = 0

#algoritmo
while numero != 1:
    print(f"O valor da variavel numero é: {numero}")
    numero = int(input("Informe 1 - para para ou quaquer numero para continuar: "))