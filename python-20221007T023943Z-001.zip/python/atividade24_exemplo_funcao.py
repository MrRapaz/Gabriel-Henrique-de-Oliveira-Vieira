""" desenvolver um algoritmo que chame uma função que receba dois números como parâmetro, realize 
a soma destes números e mostre o resultado na tela """

#variaveis
n1 = 0
n2 = 0
resultado = 0

#função
def somar_numero(numero1, numero2):
    resultado = numero1 + numero2
    print(f"A soma dos números é: {resultado}")

#algoritmo principal
n1 = int(input("informe o primeiro numero: "))
n2 = int(input("Informe o segundo número: "))
somar_numero(n1,n2)