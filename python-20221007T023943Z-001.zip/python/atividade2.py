#Faça um programa que receba o salário base de um funcionario.
#Calcule e mostre o salário a receber, sabendo que esse funcionário tem
#gratificação de R$ 50,00 e paga imposto de 10% sobre o salário base.

#sal salário
#salR salário a receber
#salB salário base

sal = 0.0
salB = 0.0
salR = 0.0

salB = float(input("Informe o salário do funcionario: "))

sal = salB
salB = (salB*0.1)
sal = ((sal - salB) + 50)

print(f"O salario do funcionario será: {sal}")