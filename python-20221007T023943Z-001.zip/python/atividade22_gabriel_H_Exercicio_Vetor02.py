''' Faça um algoritmo que leia 50 valores reais e armazene em um vetor.
Modifique o vetor de modo que os valores das posições ímpares sejam 
aumentados em 5%, e os das posições pares sejam aumentados em 2%. 
Imprima depois o vetor resultante.
OBS: Para saber se um número é par você pode estar usando o comando %. 
Ex:  10 % 2, essa linha de comando retorna o resto da divisão do número 
10 por 2, caso o resto da divisão for igual a zero, o número é par. '''

vetor = [0.0]*2
vetresult = [0.0]*2
resto = 0.0
for contador in range (0,2,1):
    vetor[contador] = float(input("informe um numero: "))

for contador in range (0,2,1):
    resto = vetor[contador] % 2
    if (resto == 0):
       vetresult[contador] = (vetor[contador] * 1.02)
    else:
        vetresult[contador] = vetor[contador] * 1.05
    print(vetresult[contador])