#variaveis

#função
def mostrar_mensagem():
    print("Trabalhando com função")

#algoritmo principal
mostrar_mensagem()