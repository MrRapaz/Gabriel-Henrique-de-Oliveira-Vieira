""" faça um algoritmo que receba 5 números inteiros e ao final mostre quem é o maior e o menor número
digitado. Deve-se fazer uma função para verificar o maior e outrar para verificar o menor.
O menor e o maior número devem ser retornados para o programa principal para , então, serem mostradas. """
nu = 0.0
maior = 0.0
menor = 9999999
def test_maior(maior,n):
    if (maior <= n):
        maior = n
    return maior
def test_menor(menor,n):
    if (menor >= n):
        menor = n
    return menor
for cont in range (5):
    nu = float(input("Digite um numero: "))
    maior = test_maior(maior, nu)
    menor = test_menor(menor, nu)

print(f"O maior número é {maior}")
print(f"O maior número é {menor}")