'''Construir um algoritmo que leia a idade de N pessoas.
 O sistema deve calcular: a média das idades, a menor e a maior idade informada.'''

contador = 0
maior = 0
menor = 9999
media = 0.0
n = int(input("Digite a quantidade de pessoas que deseja informar a idade: "))

for contador in range (0, n,1):
    x = int(input("Informe a idade: "))
    if (x > maior):
        maior = x
        if (x < menor):
            menor = x 
media += x
print(f"A média foi: {media/n} a maior idade foi: {maior} a menor idade foi: {menor}")