# Uma dona de casa resolveu buscar uma renda extra para o orçamento.
#  Pensando nesta ideia, ela decidiu que iria fazer  pão caseiro (caseirinho) e broa de milho (broinha).
#  A dona de casa vende uma certa quantidade de caseirinho e uma quantidade de broinha a cada dia.
#  Cada pão caseirinho custa R$ 0,10 e a broinha custa R$ 1,60. Ao final do dia, a dona de casa quer 
#  saber quanto arrecadou com a venda dos caseirinhos e broinhas (juntos), e também ela tem a meta 
#  de guardar 1-% do toal das vendas em uma conta poupança.
#   Você foi contratado para fazer os cálculos para a dona. Com base nestes fatos, faça um algoritmo 
#   para ler as quantidades de cseirinhos e de broinhas vendidos, e depois calcular o  valor uqe ela 
#   deve guardar na poupança. No final você deve mostrar o valor vendido de caseirinhos, o valor 
#   vendido de broinhas, o total geral vendido e o valor que deverá ser guardado na poupança

caseiro = 0
bronha = 0
total = 0 
guardar = 0

caseiro = int(input("Informe a quantidade  de caseirinhos comprado: "))
bronha = int(input("Informe a quantidade de caseirinhos comprado: "))

caseiro = (caseiro * 0.10)
bronha = (bronha * 1.60)
total = (bronha + caseiro)
guardar = (total*0.1)

print(f"o valor total de caseiros foi de {caseiro}:,.2f")
print(f"O valor total de bronha foi de {bronha:,.2f}")
print(f"O valor total de bronhas e caseiros vendidos {total:,.2f}")
print(f"O valor que você devera guardar é de {guardar:,.2f}")