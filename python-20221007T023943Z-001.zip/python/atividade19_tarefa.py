''' foi feita uma pesquisa de audiência de canal de TV em várias casas de uma certa 
cidade, num determinado dia.
    Para cada casa visitada, é fornecido o núimero do canal (9, 12, 23 ou 40).
    Fazer um algoritmo que:
    - Leia um número indetermiado de dados,
      até que seja digitado o canal 0 (zero);
    - Calcule e mostre a porcentagem de
      audiência de cada emissora;
    - Caso seja digitado algum canal fora dos
      apresentados acima, informarcomo outros canais;
    - O número 0(zero) não pode ser considerado um canal. '''
canal = 0
canal_1 = 0.0
canal_2 = 0.0
canal_3 = 0.0
canal_4 = 0.0
outros = 0.0
while (canal != 1):
    canal = int(input("Informe qual canais dos canais a seguir você faz uso (9, 12, 23 e 40) digite 0(zero) para finalizar operação: "))
    if (canal == 0):
        canal += 1
    else:
        if (canal == 12):
             canal_1 += 1
        else:
            if (canal == 23):
                canal_2 += 1
            else: 
                if (canal == 40):
                    canal_3 += 1
                else:
                    if (canal == 9):
                        canal_4 += 1
                    else: 
                        outros += 1
canal = (canal_1 + canal_2 + canal_3 + canal_4)
canal_1 = ((canal_1/ canal) *  100)
canal_2 = ((canal_2/ canal) *  100)
canal_3 = ((canal_3/ canal) *  100)
canal_4 = ((canal_4/ canal) *  100)
outros = ((outros/ canal) *  100)
print(f"a porcentagem do canal 9 : {canal_1:,.2f}%")
print(f"a porcentagem do canal 12 : {canal_2:,.2f}%")
print(f"a porcentagem do canal 23 : {canal_3:,.2f}%")
print(f"a porcentagem do canal 40 : {canal_4:,.2f}%")
print(f"a porcentagem dos outros canais : {outros:,.2f}%")