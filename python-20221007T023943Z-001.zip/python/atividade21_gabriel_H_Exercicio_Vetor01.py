''' Criar um algoritmo que leia 10 números peloteclado e exiba os 
números na ordem inversa da que os números foram digitados. '''
vet =  [0.0]*10
cont = 0
while (cont != 20):
    if(cont <= 9):
        vet[cont] = int(input("Informe o número: "))
    if(cont >= 10):
        print(vet[9-cont],' , ', end='')  
    cont += 1