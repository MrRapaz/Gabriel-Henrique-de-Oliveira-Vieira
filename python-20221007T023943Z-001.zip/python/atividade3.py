#faça um programa que receba uma medida em pés.
#faça as conversões a seguir e mostre os resultados.
#  A) polegadas
#  B) jardas
#  C) milhas
#sabeses que:
#  1 pé = 12 polegadas
#  1 jarda = 3 pés
#  1 milha = 1760 jardas

polegadas = 0.0
jardas = 0.0
milhas = 0.0
medida = 0.0

medida = float(input("Digite a medida em pés que sera convertida em polegadas, jardas e milhas:"))

polegadas = (medida*12)
jardas = (medida/3)
milhas = (medida/(3*1760))

#colocar :,.2f para formatar a quantidade de casas pós virgula

print(f"polegadas: {polegadas}, jardas: {jardas:,.2f}, milhas: {milhas:,.5f}.")