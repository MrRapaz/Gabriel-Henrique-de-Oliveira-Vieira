#O custo ao consumidor de um carro novo é a soma do preço de fábrica com o 
# porcentual de lucro do distribuidor e dos impostos ao preço de fábrica. faça
# um programa que receba o preço de fábrica de um veículo, o porcentual de
# lucro do distribuidor e o percentual de impostos.
# calcule e mostre
#   A) o valor correspondente ao lucro do distrinuidor;
#   B) o valor correspondente ao imposto;
#   C) o preço final de veículo

#valorc valor carro
#lucro lucro distribuidor
#impo imposto

valorc = 0.0
lucro = 0.0
impo = 0.0

valorc = float(input("Informe o valor do automovel: "))
lucro = float(input("Informe o valor do lucro:"))
impo = float(input("Informe o valor do imposto:"))

lucro = (valorc*(lucro/100))
impo = (valorc*(impo/100))
valorc =(lucro + impo + valorc)

print(f"O valor do lucro é de: {lucro:,.2f}")
print(f"O valor do imposto é de: {impo:,.2f}")
print(f"O valor do carro com os impostos e lucro do distribuidor é de: {valorc:,.2f}")