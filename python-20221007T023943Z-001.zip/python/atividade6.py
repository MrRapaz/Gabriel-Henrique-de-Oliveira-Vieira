# Uma empresa revendedora de sucos vende seu produto nos formatos: lata de 350 ml, garrafa de 600 ml e garrafa de 2 litros.
# faça um algoritmo que receba a quantidade comprada de cada item por uma determinada pessoa e informe ao final a quantidade
# total de litros de suc que essa pessoa comprou. Ex, suponha que a pessoa compro uma lata de 250 ml e  uma garrafa de 2 litros, o total comprado foi de 2,35 litros.

item1 = 0
item2 = 0
item3 = 0
total_litros = 0

item1 = int(input("informe a quantidade comprada de latas de 350 ml: "))
item2 = int(input("Informe a quantidade comprada de garrafas de 600 ml: "))
intem3 = int(input("Informe a quantidade comprada de garrafas de 1 litro: "))

total_litros = (item1 * (350/1000)) + (item2 *(600/1000)) + (item3 * 2)
print(f"O total de litros comprado foi: {total_litros} litros")