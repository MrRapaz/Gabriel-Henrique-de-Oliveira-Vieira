# Você está fazendo um trabalho de classificação de solo. Após colher uma amostra e verificar
# a quantidade de pontos de água presente nela, classificou a amostra em:
#   rochosa: se menos ou igual a 10 pontos de água
#   firme: se mais de 10 e menos ou igual a 40 pontos
#   pantanosa: se mais de 40 e menos ou igual a 80 pontos
#   quantidade inválida: se mais do que 80 pontos
pontos = 0
text = ""

pontos = int(input("Informe a quantidade de pontos de água no solo:"))
if(pontos <= 10):
    text = "O sólo é rochoso!"
else:
    if(pontos > 10 and pontos <= 40):
       text = "O sólo é firme!"
    else:
        if(pontos > 40 and pontos <= 80):
           text = "O sólo é pantanoso!"
        else:
            text = "Quantidade invalida!!!"
print(text)