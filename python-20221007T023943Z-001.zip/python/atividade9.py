# constua uma algoritmo que determine quanto será gasto para encher o tanque de um carro. O usuário fornecerá os seguintes
# dados: Tipo de carro (TC) (G - gasolina ou A - álcool) e Capacidade do tanque (CT), em litros. Após a escolha do tipo de 
# veículo e da capacidade do tanque, o sistema irá imprimir uma mensagem falando o tipo do carro(Gasolina ou álcool) e combustível.
# Como saída, será informado para usuário, o valor, em reais, do preço de se encher tanque de combustível.

tipo_carro = ""
tipo = ""
capacidade_tanque = 0
valor_combustivel = 0.0
valor_pagar = 0.0

tipo_carro = input("Informe o tipo de bombustivel: (G) para gasolina e (A) para élcool: ")
valor_combustivel = float(input("Informe o valor do combustivel: "))
capacidade_tanque = int(input("Iforme a capacidade do tanque do veiculo: "))

if(tipo_carro == "G"):
    tipo = "Carro a gasolina"
else:
    if(tipo_carro == "A"):
        tipo = "carro a álcool"
    else:
        tipo = "codgo não indentificado"

print(f"a capacidade do tanque do automovel é de {capacidade_tanque}")

valor_pagar = (valor_combustivel * capacidade_tanque)

print(f"O total a pagar para encher o tanque é de {valor_pagar}")
