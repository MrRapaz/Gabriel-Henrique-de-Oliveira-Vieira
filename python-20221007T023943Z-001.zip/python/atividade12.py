""" Faça um programa que recebe o salário de um funcionário, calcule e mostre o novo
salário desse funcionário, acrescido de bonificação e de auxílio escola.
         salário                      bonificação
         até R$ 500,00                5%
         entre R$ 500,00 e 1200,00    12%
         acima de R$ 1200,00          0%

         salário                 auxílio escola
         até R$ 600,00           R$150,00
         acima de R$ 600,00      R$100,00
 """
salario = 0.0

salario = float(input("Informe seu salário: "))

if(salario <= 500.99):
     salario = (salario +(salario * 0.05))
else:
    if(salario >= 501 and salario <= 1200):
        salario = (salario +(salario * 0.12))
    else:
        salario = salario
if(salario <= 600.99):
    salario = (salario + 150)
else:
    salario = (salario + 100)

print(f"O salário do cidadão é de {salario:,.2f}")